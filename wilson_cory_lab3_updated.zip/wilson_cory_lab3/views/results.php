<?
  var_dump($par2);
?>
<p>results</p>
<?
	
	

  //login->hash->check hash in database

?>
