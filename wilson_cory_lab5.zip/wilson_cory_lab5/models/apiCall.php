<?

  //match file name to view name

  class apiCall{

    public function getAPI($location){

      include $location;

    }

  }

?>
