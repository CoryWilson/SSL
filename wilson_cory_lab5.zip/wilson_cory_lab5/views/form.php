<div class="small-11 small-centered medium-10 medium-centered large-8 large-centered columns">
	<form enctype="multipart/form-data" action="?controller=home&action=processLogin" method="POST">
		<div class="row">
			<h1>Log In</h1>
		</div>
		<div class="row">
			<div class="small-11 small-centered columns">
	  			<input type="text" name="username" placeholder="Username" value="" />
	  		</div>
	  	</div>
	  	<div class="row">
	  		<div class="small-11 small-centered columns">
	  			<input type="password" name="password" placeholder="Password" value="" />
	  		</div>
	  	</div>
		<div class="row">
			<button type="submit" class="small-8 small-centered medium-7 large-6 columns">
		    	Log In
		    </button>
		</div>
	</form>
</div>