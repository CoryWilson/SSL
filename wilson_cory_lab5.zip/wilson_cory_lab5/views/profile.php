<div class="profile small-11 small-centered medium-10 medium-centered large-8 large-centered columns">
	<div class="row">
		<h1>Your Profile</h1>
	</div>
	<div class="row">
	  <h4>Hello, <? echo $par2["username"] ?></h4>
	</div>
</div>