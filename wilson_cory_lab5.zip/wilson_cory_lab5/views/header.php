<head>
  <meta charset="UTF-8">
  <title>Cory Wilson | Lab 5</title>
  <link rel="stylesheet" href="css/foundation.min.css" type="text/css" />
  <link rel="stylesheet" href="css/main.css" type="text/css" />
  <script src="//use.typekit.net/jpd4eaw.js"></script>
  <script>try{Typekit.load();}catch(e){}</script>
</head>
<header>
  <div class="icon-bar six-up">
    <a href="index.php?controller=home" class="item">
      <label>Home</label>
    </a>
    <a href="index.php?controller=home&action=addForm" class="item">
      <label>Add User</label>
    </a>
    <a href="index.php?controller=home&action=loginForm" class="item">
      <label>Log In</label>
    </a>
    <a href="index.php?controller=home&action=logOut" class="item">
      <label>Log Out</label>
    </a>
    <a href="index.php?controller=home&action=checkProfile" class="item">
      <label>Profile</label>
    </a>
    <a href="index.php?controller=home&action=weatherForm" class="item">
      <label>Check Weather</label>
    </a>

  </div>
</header>