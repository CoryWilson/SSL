<?

  //match file name to view name

  class view{

    public function getView($par='',$par2=''){

      include $par;

    }

  }

?>
