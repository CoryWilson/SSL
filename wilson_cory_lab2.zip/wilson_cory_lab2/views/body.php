<div class="home small-11 small-centered medium-10 medium-centered large-8 large-centered columns">
	<h1>Cory Wilson SSL Lab 2</h1>
	<div class="row">
		<ul>
			<li>Use the Nav Bar to move around</li>
			<li>Log In will direct you to the log in page</li>
			<li>Profile will take you to your user profile</li>
			<li>Log Out will end your session and return you home</li>
		</ul>
	</div>
</div>
