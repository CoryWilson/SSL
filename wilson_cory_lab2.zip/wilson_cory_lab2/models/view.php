<?

  class view{

    public function getView($par='',$par2=''){

      include $par;

    }

  }

?>
